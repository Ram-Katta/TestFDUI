This is a dummy zip file for testing Git repositories.
