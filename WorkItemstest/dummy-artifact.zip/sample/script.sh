#!/bin/bash
echo 'Hello from dummy zip'
